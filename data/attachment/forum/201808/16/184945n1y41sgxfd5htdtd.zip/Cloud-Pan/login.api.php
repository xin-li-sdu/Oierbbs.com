<?php  
        $user = $_POST["username"];  
        $psw = $_POST["password"];  
	session_start();
	if($_POST["captcha"] != $_SESSION["captcha"])  
        {  
            echo "<script>alert('验证码错误!'); history.go(-1);</script>";  
        } 
        if($user == "" || $psw == "")  
        {  
            echo "<script>alert('请输入用户名或密码！'); history.go(-1);</script>";  
        }  
        else 
        {  
            $con=mysqli_connect("localhost","yemaster","xxx");  
            mysqli_select_db($con,"yemaster");  
            mysqli_query($con,"set names utf8") or die(mysqli_error($con));  
            $sql = "select UName,PWord from dl_users where UName = '$user' and PWord = '$psw'";  
            $result = mysqli_query($con,$sql) or die(mysqli_error($con));  
            $num = mysqli_num_rows($result);  
            if($num)  
            {  
		$_SESSION["UName"]=$user; 
		$_SESSION["Root"]='/www/wwwroot/yemaster.xyz/pan/'.$user;
		$_SESSION["RootB"]='/www/wwwroot/yemaster.xyz/pan/'.$user;
		header("Location: main/index.php");
            }  
            else 
            {  
                echo "<script>alert('用户名或密码不正确！');history.go(-1);</script>";  
            }  
        } 
   
?>
