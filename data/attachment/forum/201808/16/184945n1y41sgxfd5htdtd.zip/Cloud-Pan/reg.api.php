<?php  
        $user = $_POST["username"];  
        $psw = $_POST["password"];  
        $psw_confirm = $_POST["confirm"];  
	session_start();
	if($_POST["captcha"] != $_SESSION["captcha"])  
        {  
            echo "<script>alert('验证码错误!'); history.go(-1);</script>";  
        } 
        else 
        {  
            if($psw == $psw_confirm)  
            {  
                $con=mysqli_connect("localhost","yemaster","xxxx");   //连接数据库  
                mysqli_select_db($con,"yemaster");  //选择数据库  
                mysqli_query($con,"set names utf8") or die(mysqli_error($con)); //设定字符集  
                $sql = "select UName from dl_users where UName = '$user'"; //SQL语句  
                $result = mysqli_query($con,$sql) or die(mysqli_error($con));   //执行SQL语句  
                $num = mysqli_num_rows($result); //统计执行结果影响的行数  
                if($num)    //如果已经存在该用户 
                {  
                    echo "<script>alert('用户名已存在'); history.go(-1);</script>";  
                }  
                else    //不存在当前注册用户名称  
                {  
                    $sql_insert = "insert into dl_users (UName,PWord,Email,Qx,Sex) values('$user','$psw','".$_POST["mail"]."','1','1')";  
                    $res_insert = mysqli_query($con,$sql_insert) or die(mysqli_error($con));
                    //$num_insert = mysql_num_rows($res_insert);  
                    if($res_insert)  
                    {  

$dir = iconv("UTF-8", "GBK", "$user");
            mkdir ($dir,0777,true);
                        echo "<script>alert('注册成功！'); history.go(-1);</script>";  
                    }  
                    else 
                    {  
                        echo "<script>alert('系统繁忙，请稍候！'); history.go(-1);</script>";  
                    }  
                }  
            }  
            else 
            {  
                echo "<script>alert('密码不一致！'); history.go(-1);</script>";  
            }  
        }  
?>
