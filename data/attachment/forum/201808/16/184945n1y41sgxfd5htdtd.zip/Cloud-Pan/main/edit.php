<?php  
    session_start();
    $fname=$_GET["filename"];
    $_GET["filename"]=$_SESSION["Root"].$_GET["filename"];
            if (!file_exists($_GET["filename"])){
                ?>
                <script>
                    alert('文件不存在!');
                    history.back(-1);
                </script>
                <?php
            }
        ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Editor</title>
        <!--导入js库-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.6/ace.js" type="text/javascript" charset="utf-8"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.6/ext-language_tools.js" type="text/javascript" charset="utf-8"></script>
    </head>
    
    <body>
        <!--代码输入框（注意请务必设置高度，否则无法显示）-->
        <pre id="code" class="ace_editor" style="min-height:400px"><textarea class="ace_text-input"><?php
    $file_path = $_GET["filename"];
if(file_exists($file_path)){
$file_arr = file($file_path);
for($i=0;$i<count($file_arr);$i++){//逐行读取文件内容
echo $file_arr[$i];
}
}
?></textarea></pre>
<form action="save.php?sv=<?php echo $fname;?>" method="post">
<input type="hidden" id="mes" name="mes" />
<button onclick="savefile()">保存</button>
</form>

        <script>
            //初始化对象
            editor = ace.edit("code");
            
            //设置风格和语言（更多风格和语言，请到github上相应目录查看）
            theme = "clouds"
            language = "<?php echo substr(strrchr($_GET["filename"], '.'), 1);?>"
            editor.setTheme("ace/theme/" + theme);
            editor.session.setMode("ace/mode/" + language);
            
            //字体大小
            editor.setFontSize(18);
            
            //设置只读（true时只读，用于展示代码）
            editor.setReadOnly(false); 
            
            //自动换行,设置为off关闭
            editor.setOption("wrap", "free")
            
            //启用提示菜单
            ace.require("ace/ext/language_tools");
            editor.setOptions({
                    enableBasicAutocompletion: true,
                    enableSnippets: true,
                    enableLiveAutocompletion: true
                });
        </script>
	<script>
	function savefile() {
            mes.value=editor.getValue();
        }
	</script>

    </body>
</html>
