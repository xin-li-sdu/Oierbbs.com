<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
    <title>文本框变成一条线的CSS代码</title>
    <style type="text/css">
        .t{

            border-top-width: 1px;
            border-right-width: 1px;
            border-bottom-width: 1px;
            border-left-width: 1px;
            border-top-style: none;
            border-right-style: none;
            border-bottom-style: solid;
            border-left-style: none;
            border-top-color: #000000;
            border-right-color: #000000;
            border-bottom-color: #000000;
            border-left-color: #000000;
            transition: all 0.30s ease-in-out;
        }
        .t:focus{
            border-bottom: 1px solid blue;
            outline: none;
        }
    </style>
</head>
<body>
<input name="MyTextfield" type="text" class="t">
</body>
</html>