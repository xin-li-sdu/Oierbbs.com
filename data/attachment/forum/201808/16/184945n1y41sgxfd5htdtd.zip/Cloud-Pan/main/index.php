<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>

    <title>DapLap Online Cloud Storage</title>
    <link rel="stylesheet" href="../css/buttons.css">
    <link rel="stylesheet" href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
        .boxleft {
	    margin-top:5%;
	    margin-left:10%;
	    margin-right:10%;
            width: 80%;
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);
        }

	.table {
		margin-left:5%;
		margin-right:5%;
		width:90%;
	}
	
	ol {
		margin-left:5%;
		margin-right:5%;
	}
	
        .boxleft:hover {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

	.dirl {
	    margin-left:10%;
	}	

	hr {
	    width:80%;
    }
    
    .button-group{
        margin-left:5%;
    }
</style>

</head>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php">DapLap Online Cloud Storage</a>
                </div>
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php">Home</a>
                    </li>
                </ul>
		<ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <?php echo $_SESSION["UName"];?> <b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> 登出</a></li>
                </ul>
            </li>
        </ul>
            </div>
    </nav>
    <br><br><br>
<ol class="breadcrumb">
    <li class="active"><?php 
    
function HumanReadableFilesize($size) {
    $mod = 1024; 
    $units = explode(' ','B KB MB GB TB PB');
    for ($i = 0; $size > $mod; $i++) {
        $size /= $mod;
    }
    return round($size, 2) . ' ' . $units[$i];
}
$str=$_SESSION["Root"];
$str = preg_replace('/^[^\/]*\//is', '', $str);
$str = preg_replace('/^[^\/]*\//is', '', $str);
$str = preg_replace('/^[^\/]*\//is', '', $str);
$str = preg_replace('/^[^\/]*\//is', '', $str);
$str = preg_replace('/^[^\/]*\//is', '', $str);
$str = preg_replace('/^[^\/]*\//is', '', $str);
echo '/'.$str;?></li>
</ol>

<div class="button-group">
<a href="newfile.php" class="button button-action">新文件</a>
<a href="newdir.php" class="button button-action button-caution">新文件夹</a>
</div>
<table class="table table-hover">
<thead>
<tr>
<th width="10%">类型</th>
<th width="63%">名称</th>
<th width="6%">大小</th>
<th width="15%">操作</th>
</tr>
</thead>
<tbody>
<?php if ($_SESSION["Root"]!=$_SESSION["RootB"]){?><tr><td><i class="fa fa-folder-o" aria-hidden="true"></i></td><td>返回上一个目录</td><td><a href="backdir.php">打开</a></td></tr>
<?php
}
if (!$_SESSION["UName"]){
	header("Location: ../login.php");
}
function read_all ($dir){
    if(!is_dir($dir)) return false;
    
    $handle = opendir($dir);

    if($handle){
        while(($fl = readdir($handle)) !== false){
            $temp = $dir.DIRECTORY_SEPARATOR.$fl;
	    $filess=DIRECTORY_SEPARATOR.$fl;
            if(is_dir($temp) && $fl!='.' && $fl != '..'){
                echo '<tr><td><i class="fa fa-folder-o" aria-hidden="true"></i>   文件夹</td><td>'.$filess.'</td><td>/</td><td><a href="opendir.php?new='.$filess.'">打开</a></td></tr>'; 
            }else{
                if($fl!='.' && $fl != '..'){

                    echo '<tr><td><i class="fa fa-file-o" aria-hidden="true"></i>   '.substr(strrchr($filess, '.'), 1).'文件</td><td>'.$filess.'</td><td>'.HumanReadableFilesize(abs(filesize($temp))).'</td><td><a href="edit.php?filename='.$filess.'">编辑</a></td></tr>';
                }
            }
        }
    }
}
read_all($_SESSION["Root"]);
?>
</tbody>
</table>
</html>

