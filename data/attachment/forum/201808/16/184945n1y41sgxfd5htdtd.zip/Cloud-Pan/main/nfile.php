<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>

    <title>DapLap Online Cloud Storage</title>
    <link rel="stylesheet" href="../css/buttons.css">
    <link rel="stylesheet" href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

    <input style="border-width:0px;border-bottom:1 solid black"/>
</body>
</html>

