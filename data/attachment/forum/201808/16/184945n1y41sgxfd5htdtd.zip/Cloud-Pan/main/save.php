<?php
session_start();
$fnames=$_SESSION["Root"].$_GET["sv"];
$myfile = fopen("$fnames", "w") or die("Unable to open file!");
$txt = $_POST["mes"];
fwrite($myfile, $txt);
fclose($myfile);
?>
<script>
    alert('保存成功!');
    history.back(-1);
</script>