<?php
	session_start();
	$_SESSION["Root"] = preg_replace('/(.*)\/{1}([^\/]*)/i', '$1', $_SESSION["Root"]);
?>
<script>
	history.back(-1);
</script>
