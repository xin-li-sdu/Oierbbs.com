<?php
	session_start();
	$_SESSION["Root"]=$_SESSION["Root"].$_GET["new"];
?>
<script>
	history.back(-1);
</script>
