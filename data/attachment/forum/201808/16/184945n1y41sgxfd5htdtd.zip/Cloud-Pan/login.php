<?php
?>
<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .boxleft {
            margin-top: 8%;
            margin-left: 35%;
            margin-right: 35%;
            width: 30%;
            position: fixed;
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);
        }

        .boxleft:hover {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        body {
            background-image: url("./bg.php");
            background-repeat: no-repeat;
            background-size: cover;
        }

        .form-captcha{
            margin-left: 3%;
            margin-right: 3%;
        }

        .form-setting {
            margin-left: 3%;
            margin-right: 3%;
        }

        .form-submit {
            margin-left: 3%;
            margin-right: 3%;
        }

        /*hr {
            width: 80%;
            border: 0;
            height: 1px;
            background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));
        }*/

        hr {
            width: 90%;
        }
        .t{
            width:100%;
            font-size:16px;
            border-top-width: 1px;
            border-right-width: 1px;
            border-bottom-width: 1px;
            border-left-width: 1px;
            border-top-style: none;
            border-right-style: none;
            border-bottom-style: solid;
            border-left-style: none;
            border-top-color: #000000;
            border-right-color: #000000;
            border-bottom-color: #000000;
            border-left-color: #000000;
            transition: all 0.30s ease-in-out;
        }
        .t:focus{
            border-bottom: 1px solid blue;
            outline: none;
        }
    </style>
</head>

<body>
    <div class="panel panel-default boxleft">
        <div class="panel-body">
            <h3 align="center">Log in to the
                <a href="index.php">LapCap</a>
            </h3>
            <hr/>
            <form action="login.api.php" method="post">
                <div class="form-group form-setting">
                    <label for="name"><i class="fa fa-user"></i> 用户</label>
                    <input name="username" type="text" class="t" id="uname" placeholder="UserName" required />
                </div>
                <div class="form-group form-setting">
                    <label for="name"><i class="fa fa-key"></i>密码</label>
                    <input name="password" type="password" class="t" id="pword" placeholder="PassWord" required />
                </div>
                <div class="form-group form-captcha">
                    <div id="top">        
                        <label for="name"><i class="fa fa-captcha"></i>验证码</label>
                    </div>
                        <input name="captcha" type="text" class="t" style="width:70%;" id="captcha" placeholder="Captcha" required />
                        <a onclick="captchaok()"><img src="captcha.php" onclick="this.src='captcha.php'"></img></a>
                </div>
                <div class="form-setting">
                    还没有账户?<a href="register.php">注册</a>一个!
                </div>
                <div class="form-group form-submit">
                    <button type="submit" class="btn btn-success">登录</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function captchaok(){
        }
    </script>
</body>

</html>
