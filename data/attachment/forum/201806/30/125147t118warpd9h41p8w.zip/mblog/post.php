<meta charset=utf8>
<?php
header('Content-Type:text/html; charset=utf-8');
require("config/config.php");
$pid=$_GET['id'];
$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

mysqli_query($conn,'set names utf8');
$sql = "SELECT title,subtitle,message,subdate FROM post WHERE id=$pid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
        $title=$row["title"];
        $subtitle=$row["subtitle"];
        $message=$row["message"];
        $subdate=$row["subdate"];
    }
} else {
    header("Location: 404.php");
}
$conn->close();
require("themes/$theme/post.php");
?>
