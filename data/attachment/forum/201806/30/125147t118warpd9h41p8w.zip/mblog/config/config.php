<?php
/*DB info*/
$servername="localhost";
$dbuser="root";
$dbpass="ylt20050418";
$dbname="MBlog";
/*Blog info*/
$bname="MasterBlog";//博客名称;
$pageinfo=5;//一页文章数
/*Themes*/
$theme="mtheme";
/*About*/
$about_me="<p>关于我，修改<code>config/config.php</code>文件即可</p>";
/*Admin*/
$usr="yemaster";
$pwd="123456";
$uploadpath="/var/www/html/mblog/upload/";
?>
