<script LANGUAGE="JavaScript">
    function openwin(){
    alert("用户名或密码错误！");
    }
   
</script>
<?php
    session_start();
    require("config/config.php");
    $user=$_POST["username"];
    $password=$_POST["password"];
    if($user==$usr&&$password==$pwd){
        $_SESSION['user_name']="yes";
        header("Location: admin/");
    }
    else {
        echo "<script language='javascript'>\n";
        echo 'alert("用户名或密码错误！");';
		echo "history.go(-1);\n";
		echo "</script>";
    }
?>
