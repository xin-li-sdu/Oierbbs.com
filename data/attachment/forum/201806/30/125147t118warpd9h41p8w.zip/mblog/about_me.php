<meta charset=utf8>
<?php
header('Content-Type:text/html; charset=utf-8');
require("config/config.php");
require("themes/$theme/about_me.php");
?>
