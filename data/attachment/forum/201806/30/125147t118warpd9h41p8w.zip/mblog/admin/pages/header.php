<?php
    session_start();
    if ($_SESSION['user_name']!="yes") header("Location: ../login.html");
?>
<nav aria-hidden="true" class="menu" id="menu" tabindex="-1">
    <div class="menu-scroll">
        <div class="menu-content">
            <a class="menu-logo" href="index.php">管理后台</a>
            <ul class="nav">
                <li>
                    <a class="waves-attach" data-toggle="collapse" href="#problems">导航</a>
                    <ul class="menu-collapse collapse in" id="problems">
                        <li>
                            <a class="waves-attach" href="index.php">主页</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="postlist.php">博客列表</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="newpost.php">写博客</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="files.php">文件管理器</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="../index.php">到前台看看</a>
                        </li>
                    </ul>
                </li>
                <!-- <li>
                    <a class="collapsed waves-attach" data-toggle="collapse" href="#user">用户</a>
                    <ul class="menu-collapse collapse" id="user">
                        <li>
                            <a class="waves-attach" href="/user.html">用户中心</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="/login.html">登录</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="/register.html">注册</a>
                        </li>
                    </ul>
                </li>-->
            </ul>
        </div>
    </div>
</nav>
