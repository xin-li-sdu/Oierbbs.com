<?php
require("../config/config.php");
require("../config/config_admin.php");
$pid=(int)($_GET["id"]);
if (!$pid) $pid=1;
$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
 
mysqli_query($conn,'set names utf8');
$sql = "DELETE FROM `post` WHERE `id`=$pid";
if (!$conn->query($sql)){ die("ERROR");}
$p=1;
$i=$pid+1;
while ($p){
   $sql = "SELECT title,subtitle,message,subdate FROM post WHERE id=$i";
$result = $conn->query($sql);

if (!$result->num_rows > 0) {
    $p=0;
}
   $sql = "UPDATE `post` SET `id`=".(int)($i-1)." WHERE `id`=$i"; 
   if (!$conn->query($sql)){ $p=0;}
   $i=$i+1;
}
echo "<script>alert('删除成功!');</script>";
header("Location index.php");
$conn->close();
?>
