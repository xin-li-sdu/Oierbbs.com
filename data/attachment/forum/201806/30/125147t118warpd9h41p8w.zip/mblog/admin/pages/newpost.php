<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
	<title>新文章 - MasterBlog</title>

	<!-- css -->
	<link href="../css/base.min.css" rel="stylesheet">
	<link href="../css/project.min.css" rel="stylesheet">
	
	<!-- favicon -->

	<script>
		document.onkeydown = function(e)
		{
			if(!e)
				e = window.event;
			if((e.keyCode || e.which) == 13)
				self.location = 'post.php?id='+document.getElementById('id').value;
		}
	</script>
	<!-- ... -->
</head>
<body class="page-brand">
	<header class="header header-transparent header-waterfall ui-header">
		<ul class="nav nav-list pull-left">
			<li>
				<a data-toggle="menu" href="#menu">
					<span class="icon icon-lg">menu</span>
				</a>
			</li>
		</ul>
        <a class="header-logo margin-left-no" href="index.php"><?php echo $bname;?></a>
		
	</header>
    <?php require("pages/header.php");?>
	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-lg-push-3 col-sm-10 col-sm-push-1">
						<h1 class="content-heading">新文章</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-lg-push-3 col-sm-10 col-sm-push-1">
					<section class="content-inner margin-top-no">
						<div class="card">
							<div class="card-main">
								<div class="card-inner">
									
									<div>
										<div class="form-group form-group-label form-group-labol">
											
											<div class="row">
												<div class="col-md-7 col-md-push-1">
												<p><?php echo date("Y年m月d日 h:i:s");?></p>
												<h3>写文章</h3>
												    <form class="form-validate form-horizontal" id="feedback_form" method="post" action="../api/post_submit.php">
<div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">id <span class="required"></span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="id" minlength="0" type="text" value="<?php echo $BlogNumber+1;?>" readonly />
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">标题 <span class="required"></span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="title" minlength="0" type="text" required />
                                          </div>
                                      </div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">摘要(subtitle)</label>
                                          <div class="col-lg-10">
                                              <textarea class="form-control " id="ccomment" name="subtitle" readonly>系统会自动截取该部分内容！</textarea>
                                          </div>
                                      </div>

<div class="form-group">
                                          <label for="ccomment" class="control-label col-lg-2">内容</label>
                                          <div class="col-lg-10">
<!--<textarea class="form-control" id="ccomment" name="message"></textarea>-->
<textarea class="form-control " id="ccomment" name="message" required></textarea>
                                          </div>
                                      </div>                  
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">时间 <span class="required"></span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="subdate" minlength="0" type="text" value="<?php echo date("Y-m-d");?>" readonly />
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-offset-2 col-lg-10">

                                              <button class="btn btn-primary" type="submit">提交</button>
                                          </div>
                                      </div>
                                  </form>
												</div>
											</div>
                                    

									</div>
								</div>
							</div>
						</div>
						
					</section>
				</div>
			</div>
		</div>
	</main>
	
	<div class="fbtn-container">
		<div class="fbtn-inner">
			<a class="fbtn fbtn-lg fbtn-brand-accent waves-attach waves-circle waves-light waves-effect" data-toggle="dropdown" aria-expanded="true"><span class="fbtn-text fbtn-text-left">Home</span><span class="fbtn-ori icon">apps</span><span class="fbtn-sub icon">close</span></a>
			<div class="fbtn-dropup">
				<a class="fbtn fbtn-brand waves-attach waves-circle waves-light waves-effect" href="blog.php" target="_self"><span class="fbtn-text fbtn-text-left">博客列表</span><span class="icon">menu</span></a>
				<a class="fbtn fbtn-green waves-attach waves-circle waves-effect" href="index.php" target="_self"><span class="fbtn-text fbtn-text-left">返回主页</span><span class="icon">home</span></a>
			</div>
		</div>
	</div>

	<!-- js -->
	<script src="../js/jquery.min.js"></script>
	<script src="../js/base.min.js"></script>
	<script src="../js/project.min.js"></script>
</body>
</html>
