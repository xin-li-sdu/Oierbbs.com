<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
	<title>系统设置 - MasterBlog</title>

	<!-- css -->
	<link href="../css/base.min.css" rel="stylesheet">
	<link href="../css/project.min.css" rel="stylesheet">
	
	<!-- favicon -->

	<script>
		document.onkeydown = function(e)
		{
			if(!e)
				e = window.event;
			if((e.keyCode || e.which) == 13)
				self.location = 'post.php?id='+document.getElementById('id').value;
		}
	</script>
	<!-- ... -->
</head>
<body class="page-brand">
	<header class="header header-transparent header-waterfall ui-header">
		<ul class="nav nav-list pull-left">
			<li>
				<a data-toggle="menu" href="#menu">
					<span class="icon icon-lg">menu</span>
				</a>
			</li>
		</ul>
        <a class="header-logo margin-left-no" href="index.php"><?php echo $bname;?></a>
		
	</header>
    <?php require("pages/header.php");?>
	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-lg-push-3 col-sm-10 col-sm-push-1">
						<h1 class="content-heading">系统设置</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-lg-push-3 col-sm-10 col-sm-push-1">
					<section class="content-inner margin-top-no">
						<div class="card">
							<div class="card-main">
								<div class="card-inner">
									
									<div>
										<div class="form-group form-group-label form-group-labol">
											
											<div class="row">
												<div class="col-md-7 col-md-push-1">
												<p><?php echo date("Y年m月d日 h:i:s");?></p>
												<h3>系统设置</h3>
												    <form class="form-validate form-horizontal" id="feedback_form" method="post" action="../api/settings.php">
<div class="form-group ">
    <label for="cname" class="control-label col-lg-2"> <span class="required"><h4>数据库设置</h4></span></label>
</div>
<div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2"> <span class="required">服务器地址</span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="servername" minlength="0" type="text" value="<?php echo $servername;?>" required />
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">数据库用户 <span class="required"></span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="dbuser" minlength="0" type="text" value="<?php echo $dbuser;?>" required />
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">数据库名 <span class="required"></span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="dbname" minlength="0" type="text" value="<?php echo $dbname;?>" required />
                                          </div>
                                      </div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">密码</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="dbpass" minlength="0" type="<?php if ($cc==0) echo "text";else echo "password";?>" value="<?php echo $dbpass;?>" required />
                                          </div>
                                      </div>
                                      <div class="form-group ">
    <label for="cname" class="control-label col-lg-2"> <span class="required"><h4>博客设置</h4></span></label>
</div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">博客名称</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="bname" minlength="0" type="text" value="<?php echo $bname;?>" required />
                                          </div>
                                      </div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">一页文章数</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="pageinfo" minlength="0" type="text" value="<?php echo $pageinfo;?>" required />
                                          </div>
                                      </div>
<div class="form-group ">
    <label for="cname" class="control-label col-lg-2"> <span class="required"><h4>关于</h4></span></label>
</div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">关于我</label>
                                          <div class="col-lg-10">
                                              <textarea class="form-control" name="about_me" minlength="0" required><?php echo $about_me;?></textarea>
                                          </div>
                                      </div><div class="form-group ">
    <label for="cname" class="control-label col-lg-2"> <span class="required"><h4>主题</h4></span></label>
</div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">主题</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="theme" value="<?php echo $theme;?>" type="text" required/>
                                          </div>
                                      </div>
                                      <div class="form-group ">
    <label for="cname" class="control-label col-lg-2"> <span class="required"><h4>管理用户</h4></span></label>
</div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">账号</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="usr" minlength="0" type="text" value="<?php echo $usr;?>" readonly />
                                          </div>
                                      </div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">密码</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="pwd" minlength="0" type="text" value="<?php echo $pwd;?>" required />
                                          </div>
                                      </div> <div class="form-group ">
    <label for="cname" class="control-label col-lg-2"> <span class="required"><h4>在线文件</h4></span></label>
</div>
<div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">上传路径</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" name="uploadpath" minlength="0" type="text" value="<?php echo $uploadpath;?>" required />
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-offset-2 col-lg-10">

                                              <button class="btn btn-primary" type="submit">提交</button>
                                          </div>
                                      </div>
                                  </form>
												</div>
											</div>
                                    

									</div>
								</div>
							</div>
						</div>
						
					</section>
				</div>
			</div>
		</div>
	</main>
	
	<div class="fbtn-container">
		<div class="fbtn-inner">
			<a class="fbtn fbtn-lg fbtn-brand-accent waves-attach waves-circle waves-light waves-effect" data-toggle="dropdown" aria-expanded="true"><span class="fbtn-text fbtn-text-left">Home</span><span class="fbtn-ori icon">apps</span><span class="fbtn-sub icon">close</span></a>
			<div class="fbtn-dropup">
				<a class="fbtn fbtn-brand waves-attach waves-circle waves-light waves-effect" href="blog.php" target="_self"><span class="fbtn-text fbtn-text-left">博客列表</span><span class="icon">menu</span></a>
				<a class="fbtn fbtn-green waves-attach waves-circle waves-effect" href="index.php" target="_self"><span class="fbtn-text fbtn-text-left">返回主页</span><span class="icon">home</span></a>
			</div>
		</div>
	</div>

	<!-- js -->
	<script src="../js/jquery.min.js"></script>
	<script src="../js/base.min.js"></script>
	<script src="../js/project.min.js"></script>
	<script>
	    function a(){
	    reax();
	    }
	</scripy>
	<?php
	    function reax(){
	    $cc=($cc+1)%2;
	    }
	?>
</body>
</html>
