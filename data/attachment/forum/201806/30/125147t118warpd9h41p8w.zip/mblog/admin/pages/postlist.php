

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
    <title>博文列表 - MasterBlog</title>

    <!-- css -->
    <link href="../css/base.min.css" rel="stylesheet">
    <link href="../css/project.min.css" rel="stylesheet">

    <!-- favicon -->

    <script>
        document.onkeydown = function(e)
        {
            if(!e)
                e = window.event;
            if((e.keyCode || e.which) == 13)
                self.location = 'post.php?id='+document.getElementById('id').value;
        }
    </script>
    <!-- ... -->
</head>
<body class="page-brand">
<header class="header header-transparent header-waterfall ui-header">
    <ul class="nav nav-list pull-left">
        <li>
            <a data-toggle="menu" href="#menu">
                <span class="icon icon-lg">menu</span>
            </a>
        </li>
    </ul>
    <a class="header-logo margin-left-no" href="index.php"><?php echo $bname;?></a>

</header>
<?php require("pages/header.php");?>
<main class="content">
    <div class="content-header ui-content-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-lg-push-3 col-sm-10 col-sm-push-1">
                    <h1 class="content-heading">博文列表</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <section class="content-inner margin-top-no">

            <div class="card">
                <div class="card-main">
                    <div class="card-inner margin-bottom-no">

                        <div class="card-table">
                            <div class="table-responsive">
                        <table class="table" title="blogset">

                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>标题</th>
                                <th>内容</th>
                                <th>日期</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            for ($i=$pageinfo*($pid-1)+1;$i<=min($BlogNumber,$pid*$pageinfo);$i++) {
                                $conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
                                // Check connection
                                if ($conn->connect_error) {
                                    die("连接失败: " . $conn->connect_error);
                                }

                                mysqli_query($conn, 'set names utf8');
                                $sql = "SELECT title,subtitle,message,subdate FROM post WHERE id=$i";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
// 输出数据
                                    while ($row = $result->fetch_assoc()) {
                                        $title = $row["title"];
                                        $subtitle = $row["subtitle"];
                                        $message = $row["message"];
                                        $subdate = $row["subdate"];
                                    }
                                }
                                $conn->close();
                                ?>
                                <tr>
                                    <td><?php echo $i;?></td>
                                    <td><?php echo $title;?></td>
                                    <td><?php echo $subtitle;?></td>
                                    <td><?php echo $subdate;?></td>
                                    <td><a href="postedit.php?id=<?php echo $i;?>">编辑</a>&nbsp;<a href="delpost.php?id=<?php echo $i;?>">删除</a></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table></div></div><!--
                        <prog>
                            <div class="progress-circular progress-circular-brand">
                                <div class="progress-circular-wrapper">
                                    <div class="progress-circular-inner">
                                        <div class="progress-circular-left">
                                            <div class="progress-circular-spinner"></div>
                                        </div>
                                        <div class="progress-circular-gap"></div>
                                        <div class="progress-circular-right">
                                            <div class="progress-circular-spinner"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </prog>

                        <lis style="display: none;">
                            <p class="card-heading">博文列表</p>
                            <div class="card-table">
                                <div class="table-responsive">

                                </div>
                            </div>
                        </lis>-->
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>

<div class="fbtn-container">
    <div class="fbtn-inner">
        <a class="fbtn fbtn-lg fbtn-brand-accent waves-attach waves-circle waves-light waves-effect" data-toggle="dropdown" aria-expanded="true"><span class="fbtn-text fbtn-text-left">Home</span><span class="fbtn-ori icon">apps</span><span class="fbtn-sub icon">close</span></a>
        <div class="fbtn-dropup">
            <a class="fbtn fbtn-brand waves-attach waves-circle waves-light waves-effect" href="blog.php" target="_self"><span class="fbtn-text fbtn-text-left">博客列表</span><span class="icon">menu</span></a>
            <a class="fbtn fbtn-green waves-attach waves-circle waves-effect" href="index.php" target="_self"><span class="fbtn-text fbtn-text-left">返回主页</span><span class="icon">home</span></a>
        </div>
    </div>
</div>

<!-- js -->
<script src="../js/jquery.min.js"></script>
<script src="../js/base.min.js"></script>
<script src="../js/project.min.js"></script>
</body>
</html>
