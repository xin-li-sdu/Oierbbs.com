<?php
require("../config/config.php");
require("../config/config_admin.php");
$id=(int)($_GET["id"]);
if (!$id) $id=1;
$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
 
mysqli_query($conn,'set names utf8');
$sql = "SELECT title,subtitle,message,subdate FROM post WHERE id=$id";
$result = $conn->query($sql);
$BlogNumber=0;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $title=$row['title'];
        $subtitle=$row['subtitle'];
        $message=$row['message'];
        $subdate=$row['subdate'];
    }
}
$conn->close();
require("pages/postedit.php");
?>
