<nav aria-hidden="true" class="menu" id="menu" tabindex="-1">
    <div class="menu-scroll">
        <div class="menu-content">
            <a class="menu-logo" href="index.php">菜单</a>
            <ul class="nav">
                <li>
                    <a class="waves-attach" data-toggle="collapse" href="#problems">导航</a>
                    <ul class="menu-collapse collapse in" id="problems">
                        <li>
                            <a class="waves-attach" href="index.php">主页</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="blog.php">博客</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="waves-attach" data-toggle="collapse" href="#about">关于</a>
                    <ul class="menu-collapse collapse" id="about">
                        <li>
                            <a class="waves-attach" href="about_me.php">关于我</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="about_project.php">关于此项目</a>
                        </li>
                    </ul>
                </li>
                <?php session_start();
if ($_SESSION['user_name']=="yes"){
                ?>
                <li>
                    <a class="waves-attach" data-toggle="collapse" href="#user">管理后台</a>
                    <ul class="menu-collapse collapse" id="user">
                        <li>
                            <a class="waves-attach" href="admin/">进入</a>
                        </li><li>
                            <a class="waves-attach" href="logout.php">登出</a>
                        </li>
                    </ul>
                </li>
                <?php
                } else { ?>
                <li>
                    <a class="waves-attach" data-toggle="collapse" href="#user">管理登陆</a>
                    <ul class="menu-collapse collapse" id="user">
                        <li>
                            <a class="waves-attach" href="login.html">登陆</a>
                        </li>
                    </ul>
                </li>
                <?php }?>
                <!-- <li>
                    <a class="collapsed waves-attach" data-toggle="collapse" href="#user">用户</a>
                    <ul class="menu-collapse collapse" id="user">
                        <li>
                            <a class="waves-attach" href="/user.html">用户中心</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="/login.html">登录</a>
                        </li>
                        <li>
                            <a class="waves-attach" href="/register.html">注册</a>
                        </li>
                    </ul>
                </li>-->
            </ul>
        </div>
    </div>
</nav>
