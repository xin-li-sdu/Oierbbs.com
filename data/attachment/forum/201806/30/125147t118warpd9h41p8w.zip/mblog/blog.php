<?php
require("config/config.php");
$pid=(int)($_GET["pid"]);
if (!$pid) $pid=1;
$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

mysqli_query($conn,'set names utf8');
$sql = "SELECT title,subtitle,message,subdate FROM post";
$result = $conn->query($sql);
$BlogNumber=0;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        ++$BlogNumber;
        $title=$row["title"];
        $subtitle=$row["subtitle"];
        $message=$row["message"];
        $subdate=$row["subdate"];
    }
}
$conn->close();
$lastpage=(int)(($BlogNumber-1)/$pageinfo)+1;
require("themes/$theme/blog.php");
?>
