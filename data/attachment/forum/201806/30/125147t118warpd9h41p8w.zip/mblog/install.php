<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>安装</title>
</head>
<body>
<?php
if (!$_POST["host"]){
?>
<form id=1 method="post">
数据库设置:<br>
ServerName:<input name="host" type="text" value="localhost" required /><br>
UserName:<input name="name" type="text" value="root" required /><br>
PassWord:<input name="pwd" type="password" value="" required /><br>
DataBaseName:<input name="dbname" type="text" value="" required /><br>
TableName:<input name="table" type="text" value="post"  readonly /><br>
<input type="submit" value="提交" />
</form>
<?php

die();
}
$host=$_POST["host"];
$name=$_POST["name"];
$pwd=$_POST["pwd"];
$table=$_POST["table"];
$dbname=$_POST["dbname"];
$conn = new mysqli($host, $name, $pwd, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

/*$sql = "CREATE TABLE `$table` (\n"

    . "  `id` int(11) NOT NULL,\n"

    . "  `title` varchar(200) COLLATE utf8mb4_bin NOT NULL,\n"

    . "  `subtitle` varchar(200) COLLATE utf8mb4_bin NOT NULL,\n"

    . "  `message` mediumtext COLLATE utf8mb4_bin NOT NULL,\n"

    . "  `subdate` date NOT NULL\n"

    . ") ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin";

if ($conn->query($sql) === TRUE){
    echo "数据库成功创建";
}
else die("创建 $table 表失败: ".$conn->error."<br>".$sql);
*/
$sql = "INSERT INTO `$table` (`id`, `title`, `subtitle`, `message`, `subdate`) VALUES ('1', 'Hello,World!','Hello,World', '<p>这是您用Mblog创建的第一篇文章，可以修改它</p>','2018-1-1')";

if ($conn->query($sql) === TRUE){
    echo "数据库成功创建";
}
else die("失败: ".$conn->error."<br>".$sql);

$conn->close();
 if (!$_GET["username"]){
?>
<form id=1 method="post">
管理员设置:<br>
UserName:<input name="username" type="text" value="yemaster" required /><br>
PassWord:<input name="password" type="password" value="" required /><br>
<input type="submit" value="提交" />
</form>
<?php
die();
}
$username=$_GET["username"];
$password=$_GET["password"];
echo "请将下列代码复制到config/config.php";
echo "<pre>";
echo "<code>";
echo '<?php<br>';
/*DB info*/
echo '$servername="'.$host.'";<br>';
echo '$dbuser="'.$name.'";<br>';
echo '$dbpass="'.$pwd.'";<br>';
echo '$dbname="'.$dbname.'";<br>';
/*Blog info*/
echo '$bname="MasterBlog";<br>';//博客名称;
echo '$pageinfo=5;<br>';//一页文章数
/*Themes*/
echo '$theme="mtheme";<br>';
/*About*/
echo '$about_me="关于我，修改<code>config/config.php</code>文件即可";<br>';
echo '$usr="'.$username.'";<br>';
echo '$pwd="'.$password.'";<br>';
echo "?><br>";
echo "</code>";
echo "</pre>";

?>
</body>
</html>
