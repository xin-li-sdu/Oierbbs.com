<?php
    session_start();
    require("config/config.php");
        $_SESSION['user_name']="lll";
        echo "<script language='javascript'>\n";
        echo 'alert("已登出！");';
		echo "history.go(-1);\n";
		echo "</script>";
?>
