<?php
sesstion_start();  
require("../include/config.php");
require("../include/config_admin.php");
$myuname=$_POST["myuname"];
$mypasswd=$_POST["mypasswd"];
if ($myuname==$username&&$mypasswd==$password) {
$loginuname=$username;
header("Location: ../admin/index.php");
}
else die("UserName or Password Wrong!");
?>
