<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
	<title>修改设置</title>

	<!-- css -->
	<link href="../css/base.min.css" rel="stylesheet">
	<link href="../css/project.min.css" rel="stylesheet">
	
	<!-- favicon -->

	<script>
		document.onkeydown = function(e)
		{
			if(!e)
				e = window.event;
			if((e.keyCode || e.which) == 13)
				self.location = 'post.php?id='+document.getElementById('id').value;
		}
	</script>
	<!-- ... -->
</head>
<?php require("../config/config.php");?>
<body class="page-brand">
	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-lg-push-3 col-sm-10 col-sm-push-1">
						<h1 class="content-heading">修改设置</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-lg-push-3 col-sm-10 col-sm-push-1">
					<section class="content-inner margin-top-no">
						<div class="card">
							<div class="card-main">
								<div class="card-inner">
									
									<div>
										<div class="form-group form-group-label form-group-labol">
											
											<div class="row">
												<div class="col-md-7 col-md-push-1">
												<p>系统无法创建文件，请将下列代码复制到config/config.php&nbsp;<a href="../index.php">返回</a></p>
												<pre>&lt;?php<br>$servername="<?php echo $_POST["servername"];?>";<br>$dbuser="<?php echo $_POST["dbuser"];?>";<br>$dbpass="<?php echo $_POST["dbpass"];?>";<br>$dbname="<?php echo $_POST["dbname"];?>";<br>$bname="<?php echo $_POST["bname"];?>";<br>$pageinfo=<?php echo $_POST["pageinfo"];?>;<br>$about_me="<?php echo htmlspecialchars($_POST["about_me"]);?>"; <br>$theme="<?php  echo $_POST["theme"];?>";<br>$usr="<?php echo $_POST["usr"];?>";<br>$pwd="<?php echo $_POST["pwd"];?>";<br>$uploadpath="<?php echo $_POST["uploadpath"];?>";<br>?&gt;
												</pre>
												</div>
											</div>
                                    

									</div>
								</div>
							</div>
						</div>
						
					</section>
				</div>
			</div>
		</div>
	</main>
	
	<div class="fbtn-container">
		<div class="fbtn-inner">
			<a class="fbtn fbtn-lg fbtn-brand-accent waves-attach waves-circle waves-light waves-effect" data-toggle="dropdown" aria-expanded="true"><span class="fbtn-text fbtn-text-left">Home</span><span class="fbtn-ori icon">apps</span><span class="fbtn-sub icon">close</span></a>
			<div class="fbtn-dropup">
				<a class="fbtn fbtn-brand waves-attach waves-circle waves-light waves-effect" href="blog.php" target="_self"><span class="fbtn-text fbtn-text-left">博客列表</span><span class="icon">menu</span></a>
				<a class="fbtn fbtn-green waves-attach waves-circle waves-effect" href="index.php" target="_self"><span class="fbtn-text fbtn-text-left">返回主页</span><span class="icon">home</span></a>
			</div>
		</div>
	</div>

	<!-- js -->
	<script src="../js/jquery.min.js"></script>
	<script src="../js/base.min.js"></script>
	<script src="../js/project.min.js"></script>
</body>
</html>
