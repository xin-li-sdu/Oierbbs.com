<?php
$login=0;
$loginuname="";

session_destroy();
header("Location: ../index.php");
?>
