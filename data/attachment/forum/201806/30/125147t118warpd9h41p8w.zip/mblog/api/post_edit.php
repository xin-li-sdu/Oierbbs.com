<?php
header("Content-Type: text/html;charset=utf-8"); 
require("../config/config.php");
function substr_cut($str_cut,$length)
{
    if (strlen($str_cut) > $length)
    {
        for($i=0; $i < $length; $i++)
        if (ord($str_cut[$i]) > 128)    $i++;
        $str_cut = substr($str_cut,0,$i)."..";
    }
    return $str_cut;
}
$id=$_POST['id'];
$title=$_POST['title'];
$subtitle=$_POST['subtitle'];
$message=$_POST['message'];
$subdate=$_POST['subdate'];
$subtitle=substr_cut($message,100);
$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
mysqli_query($conn,"SET NAMES utf8");
mysqli_query($conn,"UPDATE post SET title='$title',subtitle='$subtitle',message='$message',subdate='$subdate' 
WHERE id=$id");

/*if ($conn->query($sql) === TRUE) {
    echo "修改成功";
    header("Location: ../index.php");
} else {
    die("Error: " . $sql . "<br>" . $conn->error);
}*/
$conn->close();
header("Location: ../admin");
?>
